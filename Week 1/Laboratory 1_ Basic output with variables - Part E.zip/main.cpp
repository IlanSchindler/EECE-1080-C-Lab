
// Programmer: Fill in your name here

// This template contains some syntax 
// that you will need to correct first

#include <iostream>

using namespace std;

int main() {
   Integer userNum = 0;

   cout >> "Enter integer:" <<  endl
   cin  >> userNum
   cout << "You entered: " << userNum << endl;
   /* Type your code here 

   return 0;
}